/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onscreenkeyboard;

/**
 *
 * @author Michael Paluda
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;


public class OnScreenKeyboard {

    
    /**
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here   
        // Initialize a keyboard to work with
        Keyboard keyboard = new Keyboard();
        
        // Opens input file, uses Scanner object to read the input and PrintWriter object to write to output.txt.
        
        try {
                File file = new File("input.txt");
                Scanner sc = new Scanner(file);
                PrintWriter outWriter = new PrintWriter("output.txt");
                
                while (sc.hasNextLine()) {
                    // converts all chars in the string to uppercase and trims the whitespace surrounding the string
                    // and then converts to a character array
                    char[] parseToCharArray = sc.nextLine().toUpperCase().trim().toCharArray();
                            
                    String outputString = keyboard.getmoves(parseToCharArray);
                    
                    outWriter.println(outputString);
            }
                outWriter.close();
        } catch (FileNotFoundException ex) {
            System.out.println("ERROR");
        } 
    
    
        
        
        
        
        
        
    }
    
}
