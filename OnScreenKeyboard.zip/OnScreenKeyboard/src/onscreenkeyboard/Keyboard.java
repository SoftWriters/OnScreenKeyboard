/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onscreenkeyboard;

/**
 *
 * @author Michael Paluda
 * 
 */
import java.util.*;

public class Keyboard {
    
    // all of the characters on the keyboard, initializes the column value to 6
    private char[] characters = {'A','B','C','D','E','F','G','H','I','J',
        'K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
        '1','2','3','4','5','6','7','8','9','0'};;
    private HashMap hashMap;
    private int columns = 6;
    
    // Keyboard constructor that places the character and the index in
    // the hashmap
    public Keyboard() {
        hashMap = new HashMap();
        for (int i = 0; i < characters.length; i++ ) {
            hashMap.put(characters[i], i);
        }
           
    }
    public int getindex(char c) {
       return (int) hashMap.get(c);
    }
    
    public boolean onkeyboard(char c) {
        return hashMap.containsKey(c);
    }
    
    
    public String getmoves(char[] input) {
        //Chose list in order to use join method later
        List<String> directionsList = new ArrayList<>();
        int position;
        int destination = 0;
        
        for (int i = 0; i < input.length; i++){
            /* if the key is not on the keyboard a space is added to
            directions thus apostrophes and question marks will also be
            spaced*/
            if (!onkeyboard(input[i])) {
                directionsList.add("S");
            }
            
            else {
  
            // sets position to 0 if it is the first character, otherwise the position is the last destination
            if (i == 0) {
                position = 0;
            } else {
                position = destination;
            }
            destination = getindex(input[i]);
            
            /*the position divided by the column will be equal for all
            elements on the same row, thus the first two while loops will
            bring the cursor to the same row as the destination, the second
            two while loops will bring the cursor in the same column as the
            the destination once this is done the select key is added
            */
            while ((position / columns) < (destination / columns)) {                    
                    directionsList.add("D");
                    position += columns;
                }
            
            while ((position / columns) > (destination / columns)) {                    
                    directionsList.add("U");
                    position -= columns;
                }
            while (position < destination) {
                
                directionsList.add("R");
                position += 1;
            }
            while (position > destination) {
                
                directionsList.add("L");
                position -= 1;
            }
            
            directionsList.add("#");
            
            
            
            }
        }
        // returns the given string with commas inbetween each command
        return String.join(",", directionsList);
        
    }
}
