﻿
using System.Text;

namespace SoftwritersTest
{
    public class DVR
    {
        // sample keyboard
        /*
            ABCDEF
            GHIJKL
            MNOPQR
            STUVWX
            YZ1234
            567890          
         */
        // accepts flat file as input
        // outputs path for the DVR to execute for each line
        //        Cursor will always start on A
        //         following characters to make up the path
        /*
         *      U = up
                D = down
                L = left
                R = right
                S = space
                # = select
        */
        // Comma delimit the result
        // Sample input: IT Crowd
        // Sample output: D,R,R,#,D,D,L,#,S,U,U,U,R,#,D,D,R,R,R,#,L,L,L,#,D,R,R,#,U,U,U,L,#
        //                D,R,R,#,D,D,D,R,#,S,R,R,#,D,D,R,R,R,R,R,#,D,D,R,R,#,D,D,D,R,R,R,R,#,R,R,R,#
        public string BuildDVRString (string str)
        {
            string outputStr = "";
            char[] chars = str.ToCharArray();
            StringBuilder sbStr = new StringBuilder();
            int strLength = chars.Length - 1;
            for (int i = 0; i < chars.Length; i++)
            {
                sbStr.Append(ConcatStr(chars[i].ToString(), i, strLength));
            }
            
            return outputStr = sbStr.ToString();
        }
        private string ConcatStr (string input, int charNum, int maxLength)
        {
            string outStr = "";
            foreach (char cItem in input)
            {
                switch (cItem.ToString().ToUpper())
                {
                    case "A":
                        if (charNum < maxLength)
                        {
                            outStr = "#,";
                        }
                        else
                        {
                            outStr = "#";
                        }                       
                        break;
                    case "B":
                        if (charNum < maxLength)
                        {
                            outStr = "R,#,";
                        }
                        else
                        {
                            outStr = "R,#";
                        }
                        break;
                    case "C":
                        if (charNum < maxLength)
                        {
                            outStr = "R,R,#,";
                        }
                        else
                        {
                            outStr = "R,R,#";
                        }
                        break;
                    case "D":
                        if (charNum < maxLength)
                        {
                            outStr = "R,R,R,#,";
                        }
                        else
                        {
                            outStr = "R,R,R,#";
                        }
                        break;
                    case "E":
                        if (charNum < maxLength)
                        {
                            outStr = "R,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "R,R,R,R,#";
                        }
                        break;
                    case "F":
                        if (charNum < maxLength)
                        {
                            outStr = "R,R,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "R,R,R,R,R,#";
                        }
                        break;
                    case "G":
                        if (charNum < maxLength)
                        {
                            outStr = "D,#,";
                        }
                        else
                        {
                            outStr = "D,#";
                        }
                        break;
                    case "H":
                        if (charNum < maxLength)
                        {
                            outStr = "D,R,#,";
                        }
                        else
                        {
                            outStr = "D,R,#";
                        }
                        break;
                    case "I":
                        if (charNum < maxLength)
                        {
                            outStr = "D,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,R,R,#";
                        }
                        break;
                    case "J":
                        if (charNum < maxLength)
                        {
                            outStr = "D,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,R,R,R,#";
                        }
                        break;
                    case "K":
                        if (charNum < maxLength)
                        {
                            outStr = "D,R,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,R,R,R,R,#";
                        }
                        break;
                    case "L":
                        if (charNum < maxLength)
                        {
                            outStr = "D,R,R,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,R,R,R,R,R,#";
                        }
                        break;
                    case "M":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,#,";
                        }
                        else
                        {
                            outStr = "D,D,#";
                        }
                        break;
                    case "N":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,R,#";
                        }
                        break;
                    case "O":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,R,R,#";
                        }
                        break;
                    case "P":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,R,R,R,#";
                        }
                        break;
                    case "Q":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,R,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,R,R,R,R,#";
                        }
                        break;
                    case "R":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,R,R,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,R,R,R,R,R,#";
                        }
                        break;
                    case "S":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,#";
                        }
                        break;
                    case "T":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,R,#";
                        }
                        break;
                    case "U":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,R,R,#";
                        }
                        break;
                    case "V":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,R,R,R,#";
                        }
                        break;
                    case "W":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,R,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,R,R,R,R,#";
                        }
                        break;
                    case "X":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,R,R,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,R,R,R,R,R,#";
                        }
                        break;
                    case "Y":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,D,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,D,#";
                        }
                        break;
                    case "Z":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,D,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,D,R,#";
                        }
                        break;
                    case "1":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,D,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,D,R,R,#";
                        }
                        break;
                    case "2":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,D,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,D,R,R,R,#";
                        }
                        break;
                    case "3":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,D,R,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,D,R,R,R,R,#";
                        }
                        break;
                    case "4":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,D,R,R,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,D,R,R,R,R,R,#";
                        }
                        break;
                    case "5":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,D,D,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,D,D,#";
                        }
                        break;
                    case "6":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,D,D,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,D,D,R,#";
                        }
                        break;
                    case "7":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,D,D,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,D,D,R,R,#";
                        }
                        break;
                    case "8":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,D,D,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,D,D,R,R,R,#";
                        }
                        break;
                    case "9":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,D,D,R,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,D,D,R,R,R,R,#";
                        }
                        break;
                    case "0":
                        if (charNum < maxLength)
                        {
                            outStr = "D,D,D,D,D,R,R,R,R,R,#,";
                        }
                        else
                        {
                            outStr = "D,D,D,D,D,R,R,R,R,R,#";
                        }
                        break;
                    case " ":
                        if (charNum < maxLength)
                        {
                            outStr = "S,";
                        }
                        else
                        {
                            outStr = "S";
                        }
                        break;
                    default:
                        break;
                }
            }
            return outStr;
        }
    }
}
